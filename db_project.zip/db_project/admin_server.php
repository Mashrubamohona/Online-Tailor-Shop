<?php 

	
	    $db =mysqli_connect('localhost','root','','db_project');
		if (isset($_POST['login'])) {
		echo "1";
		$username=$_POST['username'];
		$password=$_POST['password_1'];
		echo "2";
		if(empty($username))
		{
			array_push($errors, "Username is required");
		}

		if(empty($password))
		{
			array_push($errors, "Password is required");
		}

		if (count($errors)==0) {
			
			echo "3";

			$sql = "SELECT * FROM admin WHERE Name='$username' AND pass='$password'";
			$result = mysqli_query($db,$sql);
			echo "4";
			if (mysqli_num_rows($result)==1)
			{
				echo "5";
				header('location:admin_home.php');
				///echo "<script>window.alert('success');</script>";
			}
			else
			{
				echo "6";
				array_push($errors, "Wrong username/ password");
			}
 
		}
	}
 ?>