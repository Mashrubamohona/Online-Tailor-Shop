
<?php include('admin_server.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Online Tailor Shop</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="titleuiu">
	<center><h1>Online Tailor Shop</h1></center>
</div>
<div class="header">
	<h2>User Login</h2>
</div>
<form method="post" action="admin_login.php">
	<div class="input-group">
	<label>Admin Name</label>
	<input type="text" name="username">
	</div>
	
	<div class="input-group">
	<label>Password</label>
	<input type="password" name="password_1">
	</div>

		<div class="input-group">
			<button type="submit" name="login" class="btn">Login</button>
		</div>
	</div>
	<p>
		Not yet a member? <a href="user_register.php">Sign up</a>
	</p>

</form>

</body>
</html>