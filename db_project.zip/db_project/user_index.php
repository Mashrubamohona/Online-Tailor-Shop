<!DOCTYPE html>
<html>
<head>
	<title>Online Tailor Shop</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="titleuiu">
	<center><h1>Online Tailor Shop</h1></center>
</div>
<div class="taskmenu">
	<ul>
	<li><a href="index.php">Home</a></li>
	<li><a href="user_profile.php">Profile</a></li>
	<li><a href="search.php">search</a></li>
	<li><a href="help.php">Help</a></li>
	<li><a href="user_login.php">Log out</a></li>
	</ul>
</div>

</body>
</html>