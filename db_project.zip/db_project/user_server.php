<?php 

	$username = "";
	$phone = "";
	$errors = array();
	$password= "";
	$nid="";
	$address="";

	$db =mysqli_connect('localhost','root','','db_project');
	if (isset($_POST['register'])) {
		$nid=$_POST['nid'];
		$username=$_POST['username'];
		$phone=$_POST['phone'];
		$address=$_POST['address'];
		$password_1=$_POST['password_1'];
		$password_2=$_POST['password_2'];

		if(empty($username))
		{
			array_push($errors, "Username is required");
		}
		if(empty($password_1))
		{
			array_push($errors, "Password is required");
		}
		if($password_1!=$password_2){
			array_push($errors,"Two password do not match");
		}
		if (count($errors)==0) {
			
			

			$sql = "INSERT INTO users ( phone , U_NID , Name , pass , Address , Rating , Photo ) VALUES ( '$phone' , '$nid' , '$username' , '$password_1' ,'','','')";
			mysqli_query($db,$sql);


		}}
		if (isset($_POST['login'])) {
		echo "1";
		$username=$_POST['username'];
		$password=$_POST['password_1'];
		echo "2";
		if(empty($username))
		{
			array_push($errors, "Username is required");
		}

		if(empty($password))
		{
			array_push($errors, "Password is required");
		}

		if (count($errors)==0) {
			
			echo "3";

			$sql = "SELECT * FROM users WHERE Name='$username' AND pass='$password'";
			$result = mysqli_query($db,$sql);
			echo "4";
			if (mysqli_num_rows($result)==1)
			{
				echo "5";
				header('location:user_index.php');
				///echo "<script>window.alert('success');</script>";
			}
			else
			{
				echo "6";
				array_push($errors, "Wrong username/ password");
			}
 
		}
	}
 ?>