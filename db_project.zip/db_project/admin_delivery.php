<!DOCTYPE html>
<html>
<head>
	<title>Online Tailor Shop</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="titleuiu">
	<center><h1>Online Tailor Shop</h1></center>
</div>
<div class="taskmenu">
	<ul>
	<li><a href="admin_home.php">Home</a></li>
	<li><a href="admin_user.php">User</a></li>
	<li><a href="admin_tailor.php">Tailor</a></li>
	<li><a href="admin_delivery.php">Delivery Man</a></li>
	<li><a href="admin_login.php">Log out</a></li>
	</ul>
</div>

</body>
</html>