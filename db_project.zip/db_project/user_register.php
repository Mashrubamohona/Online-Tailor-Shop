
<?php include('user_server.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Online Tailor Shop</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="titleuiu">
	<center><h1>Online Tailor Shop</h1></center>
</div>
<div class="header">
	<h2>User Register</h2>
</div>
<form method="post" action="user_register.php">
<?php include('errors.php');?>
	

	<div class="input-group">
	<label>User Name</label>
	<input type="text" name="username" value="<?php echo $username; ?>">
	</div>
	<div class="input-group">
	<label>Phone Number</label>
	<input type="text" name="phone" value="<?php echo $phone ; ?>">
	</div>

	<div class="input-group">
	<label>NID</label>
	<input type="text" name="nid" value="<?php echo $nid ; ?>">
	</div>

	<div class="input-group">
	<label>Address</label>
	<input type="text" name="address" value="<?php echo $address ; ?>">
	</div>

	<div class="input-group">
	<label>Password</label>
	<input type="password" name="password_1">
	</div>
	<div class="input-group">
	<label>Confirm Password</label>
	<input type="password" name="password_2">
	</div>
	<div>
		<div class="input-group">
			<button type="submit" name="register" class="btn">Register</button>
		</div>
	</div>
	<p>
		Already a member? <a href="user_login.php">Sign in</a>
	</p>

</form>

</body>
</html>