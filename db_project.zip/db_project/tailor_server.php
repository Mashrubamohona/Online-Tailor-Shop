<?php 
echo "hi";

	$username = "";
	$email = "";
	$errors = array();
	$password= "";
	$id="";

	$db =mysqli_connect('localhost','root','','db_project');
	if (isset($_POST['register'])) {
		$id=$_POST['id'];
		$username=$_POST['username'];
		$email=$_POST['email'];
		$password_1=$_POST['password_1'];
		$password_2=$_POST['password_2'];
		if(empty($username))
		{
			array_push($errors, "Tailor name is required");
		}
		if(empty($email))
		{
			array_push($errors, "Email is required");
		}
		if(empty($password_1))
		{
			array_push($errors, "Password is required");
		}
		if($password_1!=$password_2){
			array_push($errors,"Two password do not match");
		}
		if (count($errors)==0) {
			
			

			$sql = "INSERT INTO Tailor (T_ID, name , email , pass ) VALUES ( '$id' , '$username','$email','$password_1')";
			mysqli_query($db,$sql);


		}
		if (isset($_POST['login'])) {
		echo "ho";
		$username=$_POST['username'];
		$password=$_POST['password_1'];
		echo "ho";
		if(empty($username))
		{
			echo "hi";
			array_push($errors, "Username is required");
		}

		if(empty($password))
		{
			array_push($errors, "Password is required");
		}

		if (count($errors)==0) {
			
			

			$sql = "SELECT * FROM user WHERE name= '$username' AND pass= '$password'";
			$result = mysqli_query($db,$sql);
			if (mysqli_num_rows($result)==1)
			{

				header('location : index.php');
			}
			else
			{
				echo "ho";
				array_push($errors, "Wrong username/ password");
			}
 
		}
	}}
 ?>