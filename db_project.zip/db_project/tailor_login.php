
<?php include('tailor_server.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Online Tailor Shop</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="titleuiu">
	<center><h1>Online Tailor Shop</h1></center>
</div>
<div class="header">
	<h2>Tailor Login</h2>
</div>
<form method="post" action="tailor_login.php">
	<div class="input-group">
	<label>TailorName</label>
	<input type="text" name="username">
	</div>
	
	<div class="input-group">
	<label>Password</label>
	<input type="password" name="password_1">
	</div>

		<div class="input-group">
			<button type="submit" name="login" class="btn">Login</button>
			
		</div>
	</div>
	<p>
		Not yet a member? <a href="tailor_register.php">Sign up</a>
	</p>

</form>

</body>
</html>