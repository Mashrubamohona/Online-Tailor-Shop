
<!DOCTYPE html>
<html>
<head>
	<title>Online Tailor Shop</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="titleuiu">
	<center><h1>Online Tailor Shop</h1></center>
</div>
<div class="header">
	<h2>Welcome </h2>
</div>
<form method="post" action="Welcome.php">
	
	

		<div class="input-group">
			<button type="submit" name="login as User" class="btn">Login as User</button>
		</div>


		<div class="input-group">
			<button type="submit" name="login as Tailor" class="btn">Login as Tailor</button>
		</div>

		<div class="input-group">
			<button type="submit" name="Register as User" class="btn">Register as User</button>
		</div>

		<div class="input-group">
			<button type="submit" name="Register as Tailor" class="btn">Register as Tailor</button>
		</div>
	</div>


</form>

</body>
</html>