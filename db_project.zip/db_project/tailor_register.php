
<?php include('tailor_server.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Online Tailor Shop</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="titleuiu">
	<center><h1>Online Tailor Shop</h1></center>
</div>
<div class="header">
	<h2>Tailor Register</h2>
</div>
<form method="post" action="tailor_register.php">
<?php include('errors.php');?>
	<div class="input-group">
	<label>Tailor ID</label>
	<input type="text" name="id" value="<?php echo $id; ?>">
	</div>

	<div class="input-group">
	<label>TailorName</label>
	<input type="text" name="username" value="<?php echo $username; ?>">
	</div>
	<div class="input-group">
	<label>Email</label>
	<input type="text" name="email" value="<?php echo $email ; ?>">
	</div>
	<div class="input-group">
	<label>Password</label>
	<input type="password" name="password_1">
	</div>
	<div class="input-group">
	<label>Confirm Password</label>
	<input type="password" name="password_2">
	</div>
	<div>
		<div class="input-group">
			<button type="submit" name="register" class="btn">Register</button>
		</div>
	</div>
	<p>
		Already a member? <a href="tailor_login.php">Sign in</a>
	</p>

</form>

</body>
</html>