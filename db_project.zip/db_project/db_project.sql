-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2018 at 04:17 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `A_Id` int(10) NOT NULL,
  `Phone` int(10) DEFAULT NULL,
  `A_NID` int(15) DEFAULT NULL,
  `Name` varchar(25) DEFAULT NULL,
  `pass` varchar(20) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Rating` int(2) DEFAULT NULL,
  `Photo` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_man`
--

CREATE TABLE `delivery_man` (
  `D_Id` int(10) NOT NULL,
  `Phone` int(10) DEFAULT NULL,
  `D_NID` int(15) DEFAULT NULL,
  `Name` varchar(25) DEFAULT NULL,
  `pass` varchar(20) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Rating` int(2) DEFAULT NULL,
  `Photo` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `measurement`
--

CREATE TABLE `measurement` (
  `M_ID` int(10) NOT NULL,
  `U_ID` int(10) DEFAULT NULL,
  `Shoulder` int(3) DEFAULT NULL,
  `Chest` int(3) DEFAULT NULL,
  `Hight` int(4) DEFAULT NULL,
  `Hand` int(3) DEFAULT NULL,
  `Waist` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_t`
--

CREATE TABLE `order_t` (
  `O_ID` int(10) NOT NULL,
  `info_order` varchar(255) DEFAULT NULL,
  `Shoulder` int(3) DEFAULT NULL,
  `Chest` int(3) DEFAULT NULL,
  `Hight` int(4) DEFAULT NULL,
  `Hand` int(3) DEFAULT NULL,
  `Waist` int(4) DEFAULT NULL,
  `Type` varchar(40) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `price` int(10) DEFAULT NULL,
  `D_ID` int(10) DEFAULT NULL,
  `T_ID` int(10) DEFAULT NULL,
  `U_ID` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

CREATE TABLE `photo` (
  `P_ID` int(10) NOT NULL,
  `photo` blob,
  `owner_id` int(10) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tailor`
--

CREATE TABLE `tailor` (
  `T_Id` int(10) NOT NULL,
  `Phone` int(10) DEFAULT NULL,
  `T_NID` int(15) DEFAULT NULL,
  `Name` varchar(25) DEFAULT NULL,
  `pass` varchar(20) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Rating` int(2) DEFAULT NULL,
  `Photo` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `U_Id` int(10) NOT NULL,
  `Phone` int(10) DEFAULT NULL,
  `U_NID` int(15) DEFAULT NULL,
  `Name` varchar(25) DEFAULT NULL,
  `pass` varchar(20) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Rating` int(2) DEFAULT NULL,
  `Photo` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`U_Id`, `Phone`, `U_NID`, `Name`, `pass`, `Address`, `Rating`, `Photo`) VALUES
(9, 0, 0, 'a', 'a', '', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`A_Id`);

--
-- Indexes for table `delivery_man`
--
ALTER TABLE `delivery_man`
  ADD PRIMARY KEY (`D_Id`);

--
-- Indexes for table `measurement`
--
ALTER TABLE `measurement`
  ADD PRIMARY KEY (`M_ID`),
  ADD KEY `U_ID` (`U_ID`);

--
-- Indexes for table `order_t`
--
ALTER TABLE `order_t`
  ADD PRIMARY KEY (`O_ID`),
  ADD KEY `U_ID` (`U_ID`),
  ADD KEY `T_ID` (`T_ID`),
  ADD KEY `D_ID` (`D_ID`);

--
-- Indexes for table `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`P_ID`);

--
-- Indexes for table `tailor`
--
ALTER TABLE `tailor`
  ADD PRIMARY KEY (`T_Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`U_Id`),
  ADD UNIQUE KEY `Name` (`Name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `A_Id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `delivery_man`
--
ALTER TABLE `delivery_man`
  MODIFY `D_Id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `measurement`
--
ALTER TABLE `measurement`
  MODIFY `M_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_t`
--
ALTER TABLE `order_t`
  MODIFY `O_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `photo`
--
ALTER TABLE `photo`
  MODIFY `P_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tailor`
--
ALTER TABLE `tailor`
  MODIFY `T_Id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `U_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `measurement`
--
ALTER TABLE `measurement`
  ADD CONSTRAINT `measurement_ibfk_1` FOREIGN KEY (`U_ID`) REFERENCES `users` (`U_Id`);

--
-- Constraints for table `order_t`
--
ALTER TABLE `order_t`
  ADD CONSTRAINT `order_t_ibfk_1` FOREIGN KEY (`U_ID`) REFERENCES `users` (`U_Id`),
  ADD CONSTRAINT `order_t_ibfk_2` FOREIGN KEY (`T_ID`) REFERENCES `tailor` (`T_Id`),
  ADD CONSTRAINT `order_t_ibfk_3` FOREIGN KEY (`D_ID`) REFERENCES `delivery_man` (`D_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
